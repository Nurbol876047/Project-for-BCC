// Пример конфигурации для email
// Скопируйте этот файл в config.js и заполните своими данными

module.exports = {
    email: {
        user: 'your-email@gmail.com',        // Ваш Gmail адрес
        pass: 'your-app-password'            // Пароль приложения Gmail
    },
    port: 3000
};

